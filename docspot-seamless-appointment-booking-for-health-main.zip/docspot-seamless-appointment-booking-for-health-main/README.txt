
Backend setup for DocSpot

1. Install dependencies:
   npm install

2. Create a `.env` file with MongoDB URI or use the provided one.

3. Run server:
   npm start

4. Visit:
   http://localhost:5000
