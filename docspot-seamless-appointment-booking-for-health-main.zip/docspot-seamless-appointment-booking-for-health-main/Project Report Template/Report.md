project Report on DOCSPOT:Seamless Appointment Booking For Health Care
